package com.example.lifesaver;

import static com.karumi.dexter.Dexter.withActivity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;

public class Signup extends AppCompatActivity {

    String[] items = {"A+","B+","AB+","O+","A-","B-","AB-","O-"};
    AutoCompleteTextView auto_complete_txt;
    ArrayAdapter<String> adapterItems;
    RadioGroup radio_group;
    DatePicker age_picker;
    TextInputEditText signup_fullname,signup_username,signup_email,signup_password,signup_phone;
    Button btnSignup,btnUpload;

    String value = null;
    String item = null;

    Uri filepath;

    ProgressDialog pd;

    DatabaseReference databaseReference;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.my_color1));
        }


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ff0000"));
        actionBar.setBackgroundDrawable(colorDrawable);



        auto_complete_txt = findViewById(R.id.auto_complete_txt);
        signup_fullname = (TextInputEditText) findViewById(R.id.signup_fullname);
        signup_username = (TextInputEditText) findViewById(R.id.signup_username);
        signup_email = (TextInputEditText) findViewById(R.id.signup_email);
        signup_password = (TextInputEditText) findViewById(R.id.signup_password);
        signup_phone = (TextInputEditText) findViewById(R.id.signup_phone);
        btnSignup = (Button)findViewById(R.id.btnSignup);
        btnUpload = (Button)findViewById(R.id.btnUpload);

        age_picker = (DatePicker) findViewById(R.id.age_picker);

        // age value


        //gender value
        radio_group = (RadioGroup) findViewById(R.id.radio_group);
//        selectedGender = findViewById(radio_group.getCheckedRadioButtonId());



        adapterItems = new ArrayAdapter<String>(this,R.layout.list_item,items);
        auto_complete_txt.setAdapter(adapterItems);
        auto_complete_txt.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //item contain dropdown list data
                item = parent.getItemAtPosition(position).toString();

            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
                        ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");

                final String fullname,username,email,password,phone,bloodgroup,b_datereg;
                final int day,month,year;

                day = age_picker.getDayOfMonth();
                month = age_picker.getMonth()+1;
                year = age_picker.getYear();

                password = getMdhash(signup_password.getText().toString().trim());

                fullname = String.valueOf(signup_fullname.getText());
                username = String.valueOf(signup_username.getText());
                email = String.valueOf(signup_email.getText());
               // password = String.valueOf(signup_password.getText());
                phone = String.valueOf(signup_phone.getText());
                bloodgroup = String.valueOf(item);
                b_datereg = String.valueOf(String.valueOf(day) +"/"+String.valueOf(month)+"/"+String.valueOf(year));

                validation();

                databaseReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.hasChild(username)){

                            Snackbar.make(v,"Username is Already Registered",3000).show();

                        }
                        else{

                            databaseReference.child("Users").child(username).child("Full_name").setValue(fullname);
                            databaseReference.child("Users").child(username).child("Password").setValue(password);
                            databaseReference.child("Users").child(username).child("EmailId").setValue(email);
                            databaseReference.child("Users").child(username).child("Phone_no").setValue(phone);
                            databaseReference.child("Users").child(username).child("Birth_date").setValue(b_datereg);
                            databaseReference.child("Users").child(username).child("Gender").setValue(value);
                            databaseReference.child("Users").child(username).child("BloodGroup").setValue(bloodgroup);

                            pd=new ProgressDialog(getApplicationContext());
                            pd.setTitle("File Uploading....!!!");
                            //pd.show();

                            StorageReference reference=storageReference.child("uploads/"+System.currentTimeMillis()+".pdf");
                            reference.putFile(filepath)
                                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                            reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                @Override
                                                public void onSuccess(Uri uri) {

//                                                    final String username1 = String.valueOf(signup_username.getText());

                                                    databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
                                                            ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");

                                                    fileinfomodel obj=new fileinfomodel(uri.toString());
                                                    databaseReference.child("Users").child(username).child("Donate_Eligble_Certi").setValue(obj);

                                                    pd.dismiss();
                                                    Toast.makeText(getApplicationContext(),"File Uploaded",Toast.LENGTH_LONG).show();
//                                filelogo.setVisibility(View.INVISIBLE);
//                                cancelfile.setVisibility(View.INVISIBLE);
//                                imagebrowse.setVisibility(View.VISIBLE);
//                                filetitle.setText("");
                                                }
                                            });

                                        }
                                    })
                                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                            float percent=(100*taskSnapshot.getBytesTransferred())/taskSnapshot.getTotalByteCount();
                                            pd.setMessage("Uploaded :"+(int)percent+"%");
                                        }
                                    });

                            Snackbar.make(v,"Welcome To Life Saver",3000).show();

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });


        radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                findRadioButton(checkedId);
            }
        });


        storageReference= FirebaseStorage.getInstance().getReference();
        databaseReference= FirebaseDatabase.getInstance().getReference("mydocuments");

        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dexter.withContext( getApplicationContext())
                        .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                                Intent intent=new Intent();
                                intent.setType("application/pdf");
                                intent.setAction(Intent.ACTION_GET_CONTENT);
                                startActivityForResult(Intent.createChooser(intent,"Select Pdf Files"),101);

                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                                permissionToken.continuePermissionRequest();
                            }
                        }).check();
            }
        });


    }

    private void validation() {

        String checkspaces = "\\A\\w{1,20}\\z";

        String checkEmail = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        String checkPassword = "^"+
                //"(?=.*[0-9])" +  //at least one digit
                // "(?=.*[a-z])" +  //at least one lowercase letter
                // "(?=.*[A-Z])" +  //at least one uppercase letter
                "(?=.*[a-zA-Z])" +  //any letter
                "(?=.*[@#$%^&+=])" +  //at least one special character
                "(?=\\S+$)" +  //no white spaces
                ".{8,}" +      //at least 8 characters
                "$";

        String MobilePattern = "[0-9]{10}";

        if(signup_fullname.getText().toString().isEmpty()){
            signup_fullname.setError("This Field Can Not Be Empty");
        }else{
            signup_fullname.setError(null);
        }

        if(signup_username.getText().toString().isEmpty()){
            signup_username.setError("This Field Can Not Be Empty");
        } else if (signup_username.length()>20) {
            signup_username.setError("username is too long");
        }else if(!signup_username.equals(checkspaces)){
            signup_username.setError("No White Space Is Allowed");
        }else{
            signup_username.setError(null);
        }

        if(signup_password.getText().toString().isEmpty()){
            signup_password.setError("This Field Can Not Be Empty");
        }else if(!signup_password.equals(checkPassword)){
            signup_password.setError("Password Should Contain 8 Characters!");
        }else{
            signup_password.setError(null);
        }

        if(signup_email.getText().toString().isEmpty()){
            signup_email.setError("This Field Can Not Be Empty");
        } else if (!signup_email.equals(checkEmail)) {
            signup_email.setError("Invalid Email..");
        }else{
            signup_email.setError(null);
        }

        if(signup_phone.getText().toString().isEmpty()){
            signup_phone.setError("This Field Can Not Be Empty");
        } else if (!signup_phone.equals(MobilePattern)) {
            signup_phone.setError("Invalid Phone Number..");
        }else{
            signup_phone.setError(null);
        }

        int checkedId = radio_group.getCheckedRadioButtonId();
        if(checkedId == -1){
            //no radio button select
            Toast.makeText(this, "Please Select Gender", Toast.LENGTH_SHORT).show();
        }else{
            findRadioButton(checkedId);
        }

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int userAge = age_picker.getYear();
        int isAgeValid = currentYear - userAge;
        if(isAgeValid < 18){
            Toast.makeText(this,"You Are Not Eligible To Apply",Toast.LENGTH_SHORT).show();
        }

    }

    private String getMdhash(String toString) {

        String MD5 = "MD5";
        try {
            MessageDigest digest = MessageDigest.getInstance(MD5);
            digest.update(toString.getBytes());

            byte messageDigest[] = digest.digest();
            StringBuilder hexstring = new StringBuilder();

            for(byte aMsgDigest : messageDigest) {

                String h = Integer.toHexString(0xFF & aMsgDigest);

                while (h.length() < 2)
                    h = "0" + h;
                hexstring.append(h);
            }
            return hexstring.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==101 && resultCode==RESULT_OK)
        {
            filepath=data.getData();
            Toast.makeText(getApplicationContext(),"File Selected Successfully",
                    Toast.LENGTH_SHORT).show();
//            filelogo.setVisibility(View.VISIBLE);
//            cancelfile.setVisibility(View.VISIBLE);
//            imagebrowse.setVisibility(View.INVISIBLE);
        }
    }




    public void findRadioButton(int checkedId) {
        switch (checkedId) {
            case R.id.male:
                value = "Male";
                break;
            case R.id.female:
                value = "Female";
                break;
            case R.id.others:
                value = "Others";
                break;
        }
    }
//    //variables
//    ImageView backbtn;
//    Button next,login;
//    TextView titletext;
//    TextInputEditText fullName_signup1,username_signup1,email_signup1,password_signup1;
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_signup);
//
//        //hooks for animation
//        backbtn = findViewById(R.id.signup_back_button);
//        next = findViewById(R.id.signup_next_button);
//        login = findViewById(R.id.signup_login_button);
//        titletext = findViewById(R.id.signup_title_text);
//
//        //HOOKS FOR GET DATA
//        fullName_signup1 = findViewById(R.id.full_name_signup1);
//        email_signup1 = findViewById(R.id.email_signup1);
//        username_signup1 = findViewById(R.id.username_signup1);
//        password_signup1 = findViewById(R.id.password_signup1);
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String usernamesignup1str,passwordsignup1str,emailsignup1str,fullnamesignup1str;
//                usernamesignup1str = String.valueOf(username_signup1.getText());
//                passwordsignup1str = String.valueOf(password_signup1.getText());
//                fullnamesignup1str = String.valueOf(fullName_signup1.getText());
//                emailsignup1str = String.valueOf(email_signup1.getText());
//
//                Intent intent = new Intent(Signup.this,SignUp2ndClass.class);
//                intent.putExtra("usernamesgn",usernamesignup1str);
//                intent.putExtra("passwordsgn",passwordsignup1str);
//                intent.putExtra("fullnamesgn", fullnamesignup1str);
//                intent.putExtra("emailsgn", emailsignup1str);
//                startActivity(intent);
//            }
//        });
//
//    }
//
////    public void callNextSignupScreen(View view){
////
//////        String usernamesignup1str,passwordsignup1str,emailsignup1str,fullnamesignup1str;
//////                usernamesignup1str = String.valueOf(username_signup1.getText());
//////                passwordsignup1str = String.valueOf(password_signup1.getText());
//////                fullnamesignup1str = String.valueOf(fullName_signup1.getText());
//////                emailsignup1str = String.valueOf(email_signup1.getText());
//////
//////                Intent intent = new Intent(Signup.this,SignUp2ndClass.class);
//////                intent.putExtra("usernamesgn",usernamesignup1str);
//////                intent.putExtra("passwordsgn",passwordsignup1str);
//////                intent.putExtra("fullnamesgn", fullnamesignup1str);
//////                intent.putExtra("emailsgn", emailsignup1str);
////
////        if (!validateFullName() | !validateUserName() | !validateEmail() | !validatePassword()){
////            return;
////        }
////        else if (validateFullName() | validateUserName() | validateEmail() | validatePassword()){
////            intent = new Intent(Signup.this,SignUp2ndClass.class);
////        }
////
////        //add transition
////        Pair[] pairs = new Pair[4];
////        pairs[0] = new Pair<View,String>(backbtn,"transition_back_arrow_btn");
////        pairs[1] = new Pair<View,String>(next,"transition_next_btn");
////        pairs[2] = new Pair<View,String>(login,"transition_login_btn");
////        pairs[3] = new Pair<View,String>(titletext,"transition_title_text");
////
////        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
////            ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(Signup.this,pairs);
////            startActivity(intent,options.toBundle());
////        }
////        else{
////            startActivity(intent);
////        }
////
////    }
////
////
////    //VALIDATION FUNCTION
////    private boolean validateFullName(){
////        String val = fullName_signup1.getText().toString().trim();
////        if(val.isEmpty()){
////            fullName_signup1.setError("This Field Can Not Be Empty");
////            return false;
////        } else {
////            fullName_signup1.setError(null);
//////            fullName_signup1.setErrorEnabled(false);
////            return true;
////        }
////    }
////
////    private boolean validateUserName(){
////        String val = username_signup1.getText().toString().trim();
////        String checkspaces = "\\A\\w{1,20}\\z";
////        if(val.isEmpty()){
////            username_signup1.setError("This Field Can Not Be Empty");
////            return false;
////        } else if(val.length()>20){
////            username_signup1.setError("Username Is Too Large");
////            return false;
////        } else if (!val.matches(checkspaces)){
////            username_signup1.setError("No White Space Is Allowed");
////            return false;
////        }
////        else {
////            username_signup1.setError(null);
//////            username_signup1.setErrorEnabled(false);
////            return true;
////        }
////    }
////
////    private boolean validateEmail(){
////        String val = email_signup1.getText().toString().trim();
////        String checkEmail = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
////        if(val.isEmpty()){
////            email_signup1.setError("This Field Can Not Be Empty");
////            return false;
////        } else if (!val.matches(checkEmail)){
////            email_signup1.setError("Invalid Email..");
////            return false;
////        }
////        else {
////            email_signup1.setError(null);
//////            email_signup1.setErrorEnabled(false);
////            return true;
////        }
////    }
////
////    private boolean validatePassword(){
////        String val = password_signup1.getText().toString().trim();
////        String checkPassword = "^"+
////                //"(?=.*[0-9])" +  //at least one digit
////                // "(?=.*[a-z])" +  //at least one lowercase letter
////                // "(?=.*[A-Z])" +  //at least one uppercase letter
////                 "(?=.*[a-zA-Z])" +  //any letter
////                "(?=.*[@#$%^&+=])" +  //at least one special character
////                "(?=\\S+$)" +  //no white spaces
////                ".{8,}" +      //at least 8 characters
////                "$";
////
////        if(val.isEmpty()){
////            password_signup1.setError("This Field Can Not Be Empty");
////            return false;
////        } else if (!val.matches(checkPassword)){
////            password_signup1.setError("Password Should Contain 8 Characters!");
////            return false;
////        }
////        else {
////            password_signup1.setError(null);
//////            password_signup1.setErrorEnabled(false);
////            return true;
////        }
////
////
////    }

}