package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Profile1 extends AppCompatActivity {

    BottomNavigationView bnView;

    TextInputEditText full_name,email12,birth,phone;
    Button updatepro;
    TextView fullname,usern,bg,gender,blood_desc,blood_desc1;
    ImageView profile_image,i1,i2;
    CardView card1,card2;
    String wow1,birth1,bg1,email1,fullname1,gender1,phone1;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
            ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.my_color1));
        }


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ff0000"));
        actionBar.setBackgroundDrawable(colorDrawable);

        bnView = findViewById(R.id.bnView);
        full_name = (TextInputEditText) findViewById(R.id.full_name);
        email12 =(TextInputEditText) findViewById(R.id.email12);
        birth = (TextInputEditText) findViewById(R.id.birth);
        phone = (TextInputEditText) findViewById(R.id.phone);
        updatepro = (Button) findViewById(R.id.updatepro);
        fullname = (TextView) findViewById(R.id.fullname);
        usern = (TextView) findViewById(R.id.usern);
        bg = (TextView) findViewById(R.id.bg);
        gender = (TextView) findViewById(R.id.gender);
        profile_image = (ImageView) findViewById(R.id.profile_image);
        i1 = (ImageView) findViewById(R.id.i1);
        card1 = (CardView) findViewById(R.id.card1);
        card2 = (CardView) findViewById(R.id.card2);
        i2 = (ImageView) findViewById(R.id.i2);
        blood_desc1 = (TextView) findViewById(R.id.blood_desc1);
        blood_desc = (TextView) findViewById(R.id.blood_desc);

        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        wow1 = sharedPreferences.getString("value","");


        databaseReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.hasChild(wow1)){
                    birth1 = snapshot.child(wow1).child("Birth_date").getValue(String.class);
                    bg1 = snapshot.child(wow1).child("BloodGroup").getValue(String.class);
                    email1 = snapshot.child(wow1).child("EmailId").getValue(String.class);
                    fullname1 = snapshot.child(wow1).child("Full_name").getValue(String.class);
                    gender1 = snapshot.child(wow1).child("Gender").getValue(String.class);
                    String pass = snapshot.child(wow1).child("Password").getValue(String.class);
                    phone1 = snapshot.child(wow1).child("Phone_no").getValue(String.class);

                    full_name.setText(fullname1);
                    email12.setText(email1);
                    birth.setText(birth1);
                    phone.setText(phone1);
                    fullname.setText(fullname1);
                    usern.setText(wow1);
                    bg.setText(bg1);
                    gender.setText(gender1);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//"|" it means it execute all the statement present in if one by one
        updatepro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((namechange() | phonenumberChange() | emailChange() | dobChange())){
                    Toast.makeText(Profile1.this, "Data Updated Successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(Profile1.this, "You Did not made any changes", Toast.LENGTH_SHORT).show();
                }
            }
        });


        // Set Home selected
        bnView.setSelectedItemId(R.id.navigation_profile);

        bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch(item.getItemId())
                {
                    case R.id.navigation_bloodbank:
                        startActivity(new Intent(getApplicationContext(),BloodBank1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_Organ:
                        startActivity(new Intent(getApplicationContext(),Organ1.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.navigation_home:
                        startActivity(new Intent(getApplicationContext(),Campaign1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_pinned:
                        startActivity(new Intent(getApplicationContext(),Pinned1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_profile:

                        return true;
                    default:
                        Toast.makeText(getApplicationContext(), "default section", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });

//        // Perform item selected listener
//        bnView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//
//                switch(item.getItemId())
//                {
//                    case R.id.navigation_bloodbank:
//                        startActivity(new Intent(getApplicationContext(),BloodBank1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_Organ:
//                        startActivity(new Intent(getApplicationContext(),Organ1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//
//                    case R.id.navigation_home:
//                        startActivity(new Intent(getApplicationContext(),Campaign1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_pinned:
//                        startActivity(new Intent(getApplicationContext(),Pinned1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_profile:
//
//                        return true;
//                }
//                return true;
//            }
//        });

    }

    private boolean dobChange() {

        if(!birth1.equals(birth.getText().toString())){
            databaseReference.child("Users").child(wow1).child("Birth_date").setValue(birth.getText().toString());
            return true;
        }else{
            return false;
        }

    }

    private boolean phonenumberChange() {

        if(!phone1.equals(phone.getText().toString())){
            databaseReference.child("Users").child(wow1).child("Phone_no").setValue(phone.getText().toString());
            return true;
        }else{
            return false;
        }
    }

    private boolean emailChange(){

        if(!email1.equals(email12.getText().toString())){
            databaseReference.child("Users").child(wow1).child("EmailId").setValue(email12.getText().toString());
            return true;
        }else{
            return false;
        }
        
    }
    
    private boolean namechange() {

        if(!fullname1.equals(full_name.getText().toString())){
            databaseReference.child("Users").child(wow1).child("Full_name").setValue(full_name.getText().toString());
            return true;
        }else{
            return false;
        }

    }

//    private void gettingdata() {
//
//        Intent intent = getIntent();
//        String user_birth  = intent.getStringExtra("birth");
//        String user_bg  = intent.getStringExtra("bg");
//        String user_email  = intent.getStringExtra("email");
//        String user_fullname  = intent.getStringExtra("fullname");
//        String user_gender  = intent.getStringExtra("gender");
//        String user_phone  = intent.getStringExtra("phone");
//        String user_usern  = intent.getStringExtra("usern");
//
//        full_name.setText(user_fullname);
//        email12.setText(user_email);
//        birth.setText(user_birth);
//        phone.setText(user_phone);
//        fullname.setText(user_fullname);
//        usern.setText(user_usern);
//        bg.setText(user_bg);
//        gender.setText(user_gender);
//
//
//
//
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.mainmenu,menu);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int item_id = item.getItemId();
        if(item_id == R.id.bug_report){

            String recipientList = "neelrana79829@gmail.com";
            String[] recipients = recipientList.split(",");

            String subject = "Bug Report";

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, recipients);
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);

            intent.setType("message/rfc822");
            startActivity(Intent.createChooser(intent, "Choose an email client"));


        }else if(item_id == R.id.logout){

            logout1();

        }else if(item_id == R.id.app_rating){
            Intent i = new Intent(getApplicationContext(),AppRating.class);
            startActivity(i);

        }else if(item_id == R.id.faq){
            Intent i = new Intent(getApplicationContext(),Faq.class);
            startActivity(i);

        }else if(item_id == R.id.share){
            shareapp();
        }

        return true;
    }

    private void shareapp() {

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT,"Check out this amazing app");
        i.putExtra(Intent.EXTRA_TEXT,"Check out this amazing app \n Life Saver \n https://github.com/TuathaDeLugh/Lifedistroyer");
        startActivity(Intent.createChooser(i,"Share Via"));


    }

    private void logout1() {

        SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("flag",false);
        editor.apply();

        Intent i = new Intent(Profile1.this,Login.class);
        startActivity(i);
        finishAffinity();

    }

}