package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.Html;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

public class Campaign1 extends AppCompatActivity {

    RecyclerView recview;
    BottomNavigationView bnView;
    myadapter adapter;

    FloatingActionButton floatingActionButton;
    //Button logout;

    ImageButton voice;

    String voiceresult;
    SearchView searchView;

    boolean doubletap = false;
    final int duration = 2000;
    View view1;
    TextView tips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campaign1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.my_color1));
        }


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ff0000"));
        actionBar.setBackgroundDrawable(colorDrawable);


        // check if network is connected
        if (!isConnected(Campaign1.this))
            buildDialog(Campaign1.this).show();
        else {
            // do something
        }

    Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.tips_of_day_ui);
        dialog.setCancelable(false);

        tips = dialog.findViewById(R.id.tips);
        Button btn = dialog.findViewById(R.id.next);
        SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        Calendar today = Calendar.getInstance();
        long lastShown = prefs.getLong("lastShown", 0);

        Calendar lastShownCalendar = Calendar.getInstance();
        lastShownCalendar.setTimeInMillis(lastShown);

        if (lastShown == 0 ||
                lastShownCalendar.get(Calendar.DAY_OF_YEAR) != today.get(Calendar.DAY_OF_YEAR)) {
            // Show the dialog box
            openText();
            dialog.show();
        }
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong("lastShown", today.getTimeInMillis());
        editor.apply();

//        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
//        Calendar calendar = Calendar.getInstance();
//        Date currentDate = calendar.getTime();
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        editor.putString("last_opened_date", currentDate.toString());
//        editor.apply();
//        String lastOpenedDate = sharedPreferences.getString("last_opened_date", "");
//
//        String current = currentDate.toString();



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });

        floatingActionButton = findViewById(R.id.floatingActionButton1);
        voice = findViewById(R.id.voice);
        view1 = findViewById(android.R.id.content);
       // logout = findViewById(R.id.logout);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Campaign1.this,CreateCamp.class);
                startActivity(i);
            }
        });

        voice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVoiceDialog();
            }
        });


//        logout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
//                SharedPreferences.Editor editor = pref.edit();
//                editor.putBoolean("flag",false);
//                editor.apply();
//
//                Intent i = new Intent(Campaign1.this,Login.class);
//                startActivity(i);
//                finishAffinity();
//            }
//        });

        recview = (RecyclerView) findViewById(R.id.recview);
        recview.setLayoutManager(new LinearLayoutManager(this));
        bnView = findViewById(R.id.bnView);

        // Set Home selected
        bnView.setSelectedItemId(R.id.navigation_home);
        // Perform item selected listener

        bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch(item.getItemId())
                {
                    case R.id.navigation_bloodbank:
                        startActivity(new Intent(getApplicationContext(),BloodBank1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_home:
                        return true;
                    case R.id.navigation_Organ:
                        startActivity(new Intent(getApplicationContext(),Organ1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_pinned:
                        startActivity(new Intent(getApplicationContext(),Pinned1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_profile:
                        startActivity(new Intent(getApplicationContext(),Profile1.class));
                        overridePendingTransition(0,0);
                        return true;
                    default:
                        Toast.makeText(getApplicationContext(), "default section", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });

        FirebaseMessaging.getInstance().subscribeToTopic("weather")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        String msg = "Done";
                        if (!task.isSuccessful()) {
                            msg = "failed";
                        }

                    }
                });


//        bnView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//
//                switch(item.getItemId())
//                {
//                    case R.id.navigation_bloodbank:
//                        startActivity(new Intent(getApplicationContext(),BloodBank1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_home:
//                        return true;
//                    case R.id.navigation_Organ:
//                        startActivity(new Intent(getApplicationContext(),Organ1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_pinned:
//                        startActivity(new Intent(getApplicationContext(),Pinned1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_profile:
//                        startActivity(new Intent(getApplicationContext(),Profile1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                }
//                return true;
//            }
//        });



//students in jagya par apna database nu name
        FirebaseRecyclerOptions<model> options =
                new FirebaseRecyclerOptions.Builder<model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("campaign").child("approve"), model.class)
                        .build();
        adapter=new myadapter(options);
        recview.setAdapter(adapter);


    }

    private AlertDialog.Builder buildDialog(Campaign1 campaign1) {

        AlertDialog.Builder builder = new AlertDialog.Builder(campaign1);
        builder.setTitle("No Internet Connection");
        builder.setMessage("You need to have Mobile Data or WiFi to access Life Saver App");

        builder.setPositiveButton("OK", (dialog, which) -> {
            finishAffinity();
        });

        return builder;
    }


    private boolean isConnected(Campaign1 campaign1) {

        ConnectivityManager cm = (ConnectivityManager) campaign1.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netinfo = cm.getActiveNetworkInfo();

        if (netinfo != null && netinfo.isConnectedOrConnecting()) {
            android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            return (mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting());
        } else {
            return false;
        }

    }


    private void openText() {


            final int min = 0;
            final int max = 10;
            final int random = new Random().nextInt((max - min) + 1) + min;

            switch (random) {
                case 1:
                    tips.setText("Once a blood donor, always a “Life Saver”");
                    break;
                case 2:
                    tips.setText("Want to watch a miracle? Go and donate blood.");
                    break;
                case 3:
                    tips.setText("Don’t be “A negative”; be “O positive”");
                    break;
                case 4:
                    tips.setText("“O people”, did you know you are the Universal Donors.");
                    break;
                case 5:
                    tips.setText("Let's share our life with others.");
                    break;
                case 6:
                    tips.setText("Be a champion, be an organ donor.");
                    break;
                case 7:
                    tips.setText("Be the reason for someone’s heartbeat.");
                    break;
                case 8:
                    tips.setText("Be a saviour just by donating your blood.");
                    break;
                case 9:
                    tips.setText("A single drop of blood can make a huge difference.");
                    break;
                case 10:
                    tips.setText("Universal Recipients are people with AB blood group");
                    break;
                default:
                    tips.setText("The gift of blood is a gift to someone’s life.");

        }



    }

    private void openVoiceDialog() {

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        startActivityForResult(i,200);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 200 && resultCode == RESULT_OK)
        {
            ArrayList<String> arrayList = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            voiceresult = arrayList.get(0);
            searchView.onActionViewExpanded();
            searchView.setQuery(voiceresult,false);

        }
        else{
            Toast.makeText(this, "something was wrong", Toast.LENGTH_SHORT).show();
        }

    }

    public void onBackPressed() {
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
        } else {
            super.onBackPressed();
            finishAffinity();
        }}

//        if(doubletap){
//            finishAffinity();
//            return;
//        }else {
//            doubletap = true;
//            Snackbar.make(view1,"Press again to exit...",duration).show();
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//
//                    doubletap = false;
//
//                }
//            },duration);
//        }



    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.mainmenu,menu);
        getMenuInflater().inflate(R.menu.searchmenu,menu);

        MenuItem item = menu.findItem(R.id.search);
        searchView = (SearchView) item.getActionView();

        String myString = "Enter Pin Code";
        SpannableString spannableString = new SpannableString(myString);
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(ContextCompat.getColor(this, R.color.my_color));
        spannableString.setSpan(colorSpan, 0, myString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        searchView.setQueryHint(spannableString);

        searchView.setInputType(InputType.TYPE_CLASS_NUMBER);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                processsearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                processsearch(s);
                return false;
            }
        });


        return super.onCreateOptionsMenu(menu);


    }

    private void processsearch(String s) {

        FirebaseRecyclerOptions<model> options =
                new FirebaseRecyclerOptions.Builder<model>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("campaign").child("approve").orderByChild("pin").startAt(s).endAt(s+"\uf8ff"), model.class)
                        .build();

        adapter = new myadapter(options);
        adapter.startListening();
        recview.setAdapter(adapter);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int item_id = item.getItemId();
        if(item_id == R.id.bug_report){

            String recipientList = "neelrana79829@gmail.com";
            String[] recipients = recipientList.split(",");

            String subject = "Bug Report";

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, recipients);
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);

            intent.setType("message/rfc822");
            startActivity(Intent.createChooser(intent, "Choose an email client"));



        }else if(item_id == R.id.logout){

            logout1();

        }else if(item_id == R.id.app_rating){

            rating();

        }else if(item_id == R.id.faq){
            Intent i = new Intent(getApplicationContext(),Faq.class);
            startActivity(i);

        }else if(item_id == R.id.share){
            shareapp();
        }

        return true;
    }

    private void rating() {

        Intent i = new Intent(Campaign1.this,AppRating.class);
        startActivity(i);


    }

    private void shareapp() {

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT,"Check out this amazing app");
        i.putExtra(Intent.EXTRA_TEXT,"Check out this amazing app \n Life Saver \n https://github.com/TuathaDeLugh/Lifedistroyer");
        startActivity(Intent.createChooser(i,"Share Via"));

    }

    private void logout1() {

        SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("flag",false);
        editor.apply();

        Intent i = new Intent(Campaign1.this,Login.class);
        startActivity(i);
        finishAffinity();

    }

    @Override
    public void onPause() {
        super.onPause();
        adapter.stopListening();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onResume() {
        super.onResume();
        adapter.startListening();
        adapter.notifyDataSetChanged();
    }

}