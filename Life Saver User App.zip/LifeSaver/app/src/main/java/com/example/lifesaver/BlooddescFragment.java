package com.example.lifesaver;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class BlooddescFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    String address,answer,email,mono,name,password,pin,question,time,userid,img_blood;

    public BlooddescFragment() {
    }

    public BlooddescFragment(String address,String answer,String email,String mono,String name,String password,String pin,String question,String time,String userid,String img_blood) {
        // Required empty public constructor

        this.address = address;
        this.answer = answer;
        this.email = email;
        this.mono = mono;
        this.name = name;
        this.password = password;
        this.pin = pin;
        this.question = question;
        this.time = time;
        this.userid = userid;
        this.img_blood = img_blood;

    }

    public static BlooddescFragment newInstance(String param1, String param2) {
        BlooddescFragment fragment = new BlooddescFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_blooddesc, container, false);

        ImageButton bloodbank_back_button = view.findViewById(R.id.bloodbank_back_button);
        CircleImageView bloodbank_img = view.findViewById(R.id.bloodbank_img);
        TextView bloodbank_title_text = view.findViewById(R.id.bloodbank_title_text);
        TextInputEditText blood_ID = view.findViewById(R.id.blood_ID);
        TextInputEditText blood_fullname = view.findViewById(R.id.blood_fullname);
        TextInputEditText blood_address = view.findViewById(R.id.blood_address);
        TextInputEditText blood_email = view.findViewById(R.id.blood_email);
        TextInputEditText blood_contact = view.findViewById(R.id.blood_contact);
        TextInputEditText blood_area = view.findViewById(R.id.blood_area);
        TextInputEditText blood_time = view.findViewById(R.id.blood_time);
        ImageButton bloodbank_call = view.findViewById(R.id.bloodbank_call);
        Button blood_data = view.findViewById(R.id.blood_data);

        blood_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.yo,new BloodData());
                fr.addToBackStack(null);
                fr.commit();
            }
        });

        bloodbank_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = String.valueOf(blood_contact.getText());
                Intent intent =new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+number));
                getActivity().startActivity(intent);
            }
        });

        bloodbank_back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),BloodBank1.class);
                getActivity().startActivity(intent);
            }
        });



        blood_ID.setText(userid);
        blood_fullname.setText(name);
        blood_address.setText(address);
        blood_contact.setText(mono);
        blood_time.setText(time);
        blood_area.setText(pin);
        blood_email.setText(email);

        Glide.with(getContext()).load(img_blood).into(bloodbank_img);


        SharedPreferences sharedPref = getActivity().getSharedPreferences("Buserid", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("userid", userid);
        editor.apply();



        return view;
    }



    public void OnBackPressed()
    {
        Intent intent = new Intent(getActivity(),BloodBank1.class);
        startActivity(intent);
    }

    }
