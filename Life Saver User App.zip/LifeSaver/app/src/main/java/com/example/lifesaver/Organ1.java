package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.FirebaseDatabase;

public class Organ1 extends AppCompatActivity {

    RecyclerView recview_organ1;
    BottomNavigationView bnView;
    FloatingActionButton open;

    myadapter3 adapter12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organ1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.my_color1));
        }


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ff0000"));
        actionBar.setBackgroundDrawable(colorDrawable);

        recview_organ1 = (RecyclerView) findViewById(R.id.recview_organ1);
        recview_organ1.setLayoutManager(new LinearLayoutManager(this));
        bnView = findViewById(R.id.bnView);

        open = findViewById(R.id.open);


        // Set Home selected
       bnView.setSelectedItemId(R.id.navigation_Organ);

      bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
          @Override
          public boolean onNavigationItemSelected(@NonNull MenuItem item) {

              switch(item.getItemId())
              {
                  case R.id.navigation_bloodbank:
                      startActivity(new Intent(getApplicationContext(),BloodBank1.class));
                      overridePendingTransition(0,0);
                      return true;
                  case R.id.navigation_Organ:
                      return true;
                  case R.id.navigation_home:
                      startActivity(new Intent(getApplicationContext(),Campaign1.class));
                      overridePendingTransition(0,0);
                      return true;
                  case R.id.navigation_pinned:
                      startActivity(new Intent(getApplicationContext(),Pinned1.class));
                      overridePendingTransition(0,0);
                      return true;
                  case R.id.navigation_profile:
                      startActivity(new Intent(getApplicationContext(),Profile1.class));
                      overridePendingTransition(0,0);
                      return true;
                  default:
                      Toast.makeText(Organ1.this, "default section", Toast.LENGTH_SHORT).show();
              }

              return true;
          }
      });

      open.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent i = new Intent(getApplicationContext(),OrganForm.class);
              startActivity(i);
          }
      });

//        // Perform item selected listener
//        bnView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//
//                switch(item.getItemId())
//                {
//                    case R.id.navigation_bloodbank:
//                        startActivity(new Intent(getApplicationContext(),BloodBank1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_Organ:
//                        return true;
//                    case R.id.navigation_home:
//                        startActivity(new Intent(getApplicationContext(),Campaign1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_pinned:
//                        startActivity(new Intent(getApplicationContext(),Pinned1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_profile:
//                        startActivity(new Intent(getApplicationContext(),Profile1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                }
//                return true;
//            }
//        });


        FirebaseRecyclerOptions<model2> options =
                new FirebaseRecyclerOptions.Builder<model2>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("organ").child("userid"), model2.class)
                        .build();
        adapter12=new myadapter3(options);
        recview_organ1.setAdapter(adapter12);



    }
    @Override
    public void onStart() {
        super.onStart();
        adapter12.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter12.stopListening();
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter12.startListening();
        adapter12.notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        adapter12.stopListening();
        adapter12.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.mainmenu,menu);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int item_id = item.getItemId();
        if(item_id == R.id.bug_report){

            String recipientList = "neelrana79829@gmail.com";
            String[] recipients = recipientList.split(",");

            String subject = "Bug Report";

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, recipients);
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);

            intent.setType("message/rfc822");
            startActivity(Intent.createChooser(intent, "Choose an email client"));


        }else if(item_id == R.id.logout){

            logout1();

        }else if(item_id == R.id.app_rating){
            Intent i = new Intent(getApplicationContext(),AppRating.class);
            startActivity(i);

        }else if(item_id == R.id.faq){

            Intent i = new Intent(getApplicationContext(),Faq.class);
            startActivity(i);


        }else if(item_id == R.id.share){
            shareapp();
        }

        return true;
    }

    private void shareapp() {

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT,"Check out this amazing app");
        i.putExtra(Intent.EXTRA_TEXT,"Check out this amazing app \n Life Saver \n https://github.com/TuathaDeLugh/Lifedistroyer");
        startActivity(Intent.createChooser(i,"Share Via"));


    }

    private void logout1() {

        SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("flag",false);
        editor.apply();

        Intent i = new Intent(Organ1.this,Login.class);
        startActivity(i);
        finishAffinity();

    }

}