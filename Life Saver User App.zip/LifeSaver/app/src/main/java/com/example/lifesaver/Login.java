package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Login extends AppCompatActivity {

//    EditText username;
//    EditText password;

    TextInputEditText username,password;

//    FirebaseAuth mAuth;

    Button btnLogin;
    Button signup,fp;

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
            ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");
//    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
//            ("https://finalproject1-c0216-default-rtdb.firebaseio.com");



//    @Override
//    public void onStart() {
//        super.onStart();
//        // Check if user is signed in (non-null) and update UI accordingly.
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if(currentUser != null){
//            Intent iHome = new Intent(Login.this,HomeActivity.class);
//            startActivity(iHome);
//            finish();
//        }
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.my_color1));
        }


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ff0000"));
        actionBar.setBackgroundDrawable(colorDrawable);


        btnLogin = findViewById(R.id.btnLogin);
        signup = findViewById(R.id.signup);

        //mAuth = FirebaseAuth.getInstance();

        username = findViewById(R.id.username1);
        password = findViewById(R.id.password1);
        fp = findViewById(R.id.fp);


        fp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Forget.class);
                startActivity(i);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // code for varifiaction

//                SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
//                SharedPreferences.Editor editor = pref.edit();
//
//                editor.putBoolean("flag",true);
//                editor.apply();
                validation();

                final String usernamestr,passwordstr;
                usernamestr = username.getText().toString().trim();
                passwordstr = getMdhash(password.getText().toString().trim());

                if(TextUtils.isEmpty(usernamestr) || TextUtils.isEmpty(passwordstr)){
                    Toast.makeText(Login.this,
                            "Enter Username and password", Toast.LENGTH_SHORT).show();
                    return;
                }
                else{

                    databaseReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.hasChild(usernamestr)){

                                final String getpassword = snapshot.child(usernamestr)
                                        .child("Password").getValue(String.class);

                                if (getpassword.equals(passwordstr)){

                                    Snackbar.make(view,"Logged In Successfully",3000).show();

                                    share();


                                    Intent intent = new Intent(getApplicationContext(),Campaign1.class);
                                    startActivity(intent);
                                    finish();

                                }
                                else{
                                    // for password
                                    Snackbar.make(view,"Your Username Or Password Is Incorrect",3000).show();

                                }

                            }
                            else{
                                // for username
                                Snackbar.make(view,"Your Username Or Password Is Incorrect",3000).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }


//                mAuth.signInWithEmailAndPassword(usernamestr, passwordstr)
//                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                            @Override
//                            public void onComplete(@NonNull Task<AuthResult> task) {
//                                if (task.isSuccessful()) {
//                                    // Sign in success, update UI with the signed-in user's information
//                                    Toast.makeText(getApplicationContext(), "Login Successful",
//                                            Toast.LENGTH_SHORT);
//                                    Intent iHome = new Intent(Login.this,HomeActivity.class);
//                                    startActivity(iHome);
//                                    finish();
//                                } else {
//                                    // If sign in fails, display a message to the user.
//                                    Toast.makeText(Login.this, "Authentication failed.",
//                                            Toast.LENGTH_SHORT).show();
//                                }
//                            }
//                        });



            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // code for varifiaction


                Intent iHome = new Intent(Login.this,Signup.class);
                startActivity(iHome);

            }
        });
    }

    private void validation() {

        if(username.getText().toString().isEmpty()){
            username.setError("This Field Can Not Be Empty");
        }else{
            username.setError(null);
        }
        String checkPassword = "^"+
                //"(?=.*[0-9])" +  //at least one digit
                // "(?=.*[a-z])" +  //at least one lowercase letter
                // "(?=.*[A-Z])" +  //at least one uppercase letter
                "(?=.*[a-zA-Z])" +  //any letter
                "(?=.*[@#$%^&+=])" +  //at least one special character
                "(?=\\S+$)" +  //no white spaces
                ".{8,}" +      //at least 8 characters
                "$";

        if(password.getText().toString().isEmpty()){
            password.setError("This Field Can Not Be Empty");
        }else if(!password.equals(checkPassword)){
            password.setError("Password Should Contain 8 Characters!");
        }else{
            password.setError(null);
        }

    }

    private String getMdhash(String toString) {

        String MD5 = "MD5";
        try {
            MessageDigest digest = MessageDigest.getInstance(MD5);
            digest.update(toString.getBytes());

            byte messageDigest[] = digest.digest();
            StringBuilder hexstring = new StringBuilder();

            for(byte aMsgDigest : messageDigest) {

                String h = Integer.toHexString(0xFF & aMsgDigest);

                while (h.length() < 2)
                    h = "0" + h;
                hexstring.append(h);
            }
            return hexstring.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";


    }

    private void share() {

        SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("flag",true);
        editor.apply();

        SharedPreferences sharedPref = getSharedPreferences("myKey", MODE_PRIVATE);
        SharedPreferences.Editor editor1 = sharedPref.edit();
        editor1.putString("value",username.getText().toString().trim());
        editor1.apply();


    }
}