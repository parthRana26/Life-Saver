package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap gMap;
    FrameLayout map;

    Double a,b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps2);

//        map = findViewById(R.id.map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        this.gMap = googleMap;

        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                MarkerOptions markerOptions = new MarkerOptions();
                //set position of marker
                markerOptions.position(latLng);
                //set title of marker
                markerOptions.title(latLng.latitude+":"+latLng.longitude);



                //remove all markers
                googleMap.clear();
                //animating to ZOOM the marker
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,10));
                //Add marker on MAP
                googleMap.addMarker(markerOptions);

                a = latLng.latitude;
                b = latLng.longitude;


            }
        });



//        LatLng mapIndia = new LatLng(20.5937,78.9629);
//        this.gMap.addMarker(new MarkerOptions().position(mapIndia).title("Marker in india"));
//        this.gMap.moveCamera(CameraUpdateFactory.newLatLng(mapIndia));
//        this.gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mapIndia,16f));

    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(),CreateCamp.class);
        intent.putExtra("a",a);
        intent.putExtra("b",b);
        startActivity(intent);
        finish();

    }
}