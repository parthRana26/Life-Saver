package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.List;

public class Pinned1 extends AppCompatActivity {

    BottomNavigationView bnView;
    RecyclerView recview_pinne1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pinned1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.my_color1));
        }


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ff0000"));
        actionBar.setBackgroundDrawable(colorDrawable);

        bnView = findViewById(R.id.bnView);
        Button ok = findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity2.class));
            }
        });

        // Initialize and assign variable

        // Set Home selected
        bnView.setSelectedItemId(R.id.navigation_pinned);

        bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch(item.getItemId())
                {
                    case R.id.navigation_bloodbank:
                        startActivity(new Intent(getApplicationContext(),BloodBank1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_pinned:
                        return true;
                    case R.id.navigation_Organ:
                        startActivity(new Intent(getApplicationContext(),Organ1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_home:
                        startActivity(new Intent(getApplicationContext(),Campaign1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_profile:
                        startActivity(new Intent(getApplicationContext(),Profile1.class));
                        overridePendingTransition(0,0);
                        return true;
                    default:
                        Toast.makeText(getApplicationContext(), "default section", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });

//        // Perform item selected listener
//        bnView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//
//                switch(item.getItemId())
//                {
//                    case R.id.navigation_bloodbank:
//                        startActivity(new Intent(getApplicationContext(),BloodBank1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_pinned:
//                        return true;
//                    case R.id.navigation_Organ:
//                        startActivity(new Intent(getApplicationContext(),Organ1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_home:
//                        startActivity(new Intent(getApplicationContext(),Campaign1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_profile:
//                        startActivity(new Intent(getApplicationContext(),Profile1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                }
//                return true;
//            }
//        });

        getroomdata();


    }

    private void getroomdata() {

        AppDatabase db = Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"cart_db").allowMainThreadQueries().build();
        ProductDao productDao = db.ProductDao();

        recview_pinne1 = findViewById(R.id.recview_pinned1);
        recview_pinne1.setLayoutManager(new LinearLayoutManager(this));
        List<Product> products = productDao.getallproduct();
        myadapter2 adapter2 = new myadapter2(products);
        recview_pinne1.setAdapter(adapter2);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.mainmenu,menu);


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int item_id = item.getItemId();
        if(item_id == R.id.bug_report){

            String recipientList = "neelrana79829@gmail.com";
            String[] recipients = recipientList.split(",");

            String subject = "Bug Report";

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, recipients);
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);

            intent.setType("message/rfc822");
            startActivity(Intent.createChooser(intent, "Choose an email client"));



        }else if(item_id == R.id.logout){

            logout1();

        }else if(item_id == R.id.app_rating){
            Intent i = new Intent(getApplicationContext(),AppRating.class);
            startActivity(i);

        }else if(item_id == R.id.faq){
            Intent i = new Intent(getApplicationContext(),Faq.class);
            startActivity(i);

        }else if(item_id == R.id.share){
            shareapp();
        }

        return true;
    }

    private void shareapp() {

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT,"Check out this amazing app");
        i.putExtra(Intent.EXTRA_TEXT,"Check out this amazing app \n Life Saver \n https://github.com/TuathaDeLugh/Lifedistroyer");
        startActivity(Intent.createChooser(i,"Share Via"));


    }

    private void logout1() {

        SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("flag",false);
        editor.apply();

        Intent i = new Intent(Pinned1.this,Login.class);
        startActivity(i);
        finishAffinity();

    }

}