package com.example.lifesaver;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListAdapter;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity2 extends AppCompatActivity {

    myadapter4 adapterll;

    RecyclerView datagrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        datagrid = findViewById(R.id.datagrid);
        datagrid.setLayoutManager(new LinearLayoutManager(this));


        FirebaseRecyclerOptions<model3> options =
                new FirebaseRecyclerOptions.Builder<model3>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("ok"), model3.class)
                        .build();
        adapterll=new myadapter4(options);
        datagrid.setAdapter(adapterll);

    }

    @Override
    public void onStart()
    {
        super.onStart();
        adapterll.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapterll.stopListening();
    }

}