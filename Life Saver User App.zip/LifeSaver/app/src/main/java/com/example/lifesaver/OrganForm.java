package com.example.lifesaver;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class OrganForm extends AppCompatActivity {

    TextInputEditText oname1,omobile1,oaddress1,opin1,oid1;

    DatePicker odatepicker1;
    Button osubmit,osubmit1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organ_form);

        oname1 = findViewById(R.id.oname);
        omobile1 = findViewById(R.id.omobile);
        oaddress1 = findViewById(R.id.oaddress);
        opin1 = findViewById(R.id.opin);
        odatepicker1 = findViewById(R.id.odatepicker1);
        osubmit = findViewById(R.id.osubmit);
        osubmit1 = findViewById(R.id.osubmit1);
        oid1 = findViewById(R.id.oid1);


        osubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AppDatabase db = Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"cart_db").allowMainThreadQueries().build();
                ProductDao productDao = db.ProductDao();

                Boolean check = productDao.is_exist(Integer.parseInt(oid1.getText().toString()));
                if(check == false){

                    int oid = Integer.parseInt(oid1.getText().toString());
                    String oname = oname1.getText().toString();
                    String omobile = omobile1.getText().toString();
                    String oaddress = oaddress1.getText().toString();
                    String opin = opin1.getText().toString();

                    String day = String.valueOf(odatepicker1.getDayOfMonth());
                    String month = String.valueOf(odatepicker1.getMonth() + 1);
                    String year = String.valueOf(odatepicker1.getYear());
                    String date = String.valueOf(String.valueOf(day) + "/" + String.valueOf(month) + "/" + String.valueOf(year));


                    productDao.insertrecord(new Product(oid,oname,omobile,oaddress,opin,date));

                    oid1.setEnabled(false);
                    oname1.setEnabled(false);
                    omobile1.setEnabled(false);
                    oaddress1.setEnabled(false);
                    opin1.setEnabled(false);
                    odatepicker1.setEnabled(false);

                    Toast.makeText(OrganForm.this, "Successfully", Toast.LENGTH_SHORT).show();

                }
                else{
                    oid1.setText("");
                    oname1.setText("");
                    omobile1.setText("");
                    oaddress1.setText("");
                    opin1.setText("");

                    Toast.makeText(OrganForm.this, "Already in Cart", Toast.LENGTH_SHORT).show();

                }


            }
        });





    }
}