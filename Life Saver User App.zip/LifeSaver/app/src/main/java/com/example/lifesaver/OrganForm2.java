package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class OrganForm2 extends AppCompatActivity {

    TextInputEditText updatename,updatemobileno,updateaddress,updatepin,updatedeath,updateuserid;

    int updateid;

    Button updatesubmit,updatesubmit1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organ_form2);
        getSupportActionBar().hide();


        updatename = findViewById(R.id.updatename);
        updatemobileno = findViewById(R.id.updatemobileno);
        updateaddress = findViewById(R.id.updateaddress);
        updatepin = findViewById(R.id.updatepin);
        updatedeath = findViewById(R.id.updatedeath);
        updatesubmit = findViewById(R.id.updatesubmit);
        updatesubmit1 = findViewById(R.id.updatesubmit1);
        updateuserid = findViewById(R.id.updateuserid);

        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        String wow1 = sharedPreferences.getString("value","");


        updateid = Integer.parseInt(getIntent().getStringExtra("cid"));
        updatename.setText(getIntent().getStringExtra("cname"));
        updatemobileno.setText(getIntent().getStringExtra("stime"));
        updateaddress.setText(getIntent().getStringExtra("etime"));
        updatepin.setText(getIntent().getStringExtra("tagline"));
        updatedeath.setText(getIntent().getStringExtra("area"));
        updateuserid.setText(wow1);

        updatesubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AppDatabase db = Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"cart_db").allowMainThreadQueries().build();
                ProductDao productDao = db.ProductDao();

                productDao.updateById(updateid,updatename.getText().toString(),updatemobileno.getText().toString(),updateaddress.getText().toString(),updatepin.getText().toString(),updatedeath.getText().toString());
                startActivity(new Intent(getApplicationContext(),Pinned1.class));
                finish();


            }
        });


        updatesubmit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
                        ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");


                databaseReference.child("organ").child("userid").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        {

                            databaseReference.child("organ").child("userid").child(wow1).child("address").setValue(updateaddress.getText().toString().trim());
                            databaseReference.child("organ").child("userid").child(wow1).child("deathday").setValue(updatedeath.getText().toString().trim());
                            databaseReference.child("organ").child("userid").child(wow1).child("mobileno").setValue(updatemobileno.getText().toString().trim());
                            databaseReference.child("organ").child("userid").child(wow1).child("organname").setValue(updatename.getText().toString().trim());
                            databaseReference.child("organ").child("userid").child(wow1).child("pincode").setValue(updatepin.getText().toString().trim());
                            databaseReference.child("organ").child("userid").child(wow1).child("organuserid").setValue(updateuserid.getText().toString().trim());

                            Snackbar.make(v,"Thank You "+" "+wow1,3000).show();


                            updatename.setText("");
                            updateaddress.setText("");
                            updatedeath.setText("");
                            updatemobileno.setText("");
                            updatepin.setText("");
                            updateuserid.setText("");


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}