package com.example.lifesaver;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.List;

public class myadapter2 extends RecyclerView.Adapter<myadapter2.myviewholder2> {

    List<Product> products;

    public myadapter2(List<Product> products) {
        this.products = products;

    }



    @NonNull
    @Override
    public myadapter2.myviewholder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerowdesignoop,parent,false);
        return new myviewholder2(view);
    }



    @Override
    public void onBindViewHolder(@NonNull myadapter2.myviewholder2 holder, @SuppressLint("RecyclerView") int position) {
        holder.organid.setText(String.valueOf(products.get(position).getOid()));
        holder.organname.setText(products.get(position).getOname());
        holder.organmobileno.setText(products.get(position).getMobileno());
        holder.organaddress.setText(products.get(position).getAddress());
        holder.organpincode.setText(products.get(position).getPincode());
        holder.organdeathday.setText(products.get(position).getDeathday());


        holder.organdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppDatabase db = Room.databaseBuilder(holder.organid.getContext(),
                        AppDatabase.class, "cart_db").allowMainThreadQueries().build();
                ProductDao productDao = db.ProductDao();

                productDao.deleteById(products.get(position).getOid());
                products.remove(position);
                notifyItemRemoved(position);
                //updateprice();
            }
        });

        holder.organupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(new Intent(holder.organupdate.getContext(),OrganForm2.class));
                intent.putExtra("cid",String.valueOf(products.get(position).getOid()));
                intent.putExtra("cname",products.get(position).getOname());
                intent.putExtra("stime",products.get(position).getMobileno());
                intent.putExtra("etime",products.get(position).getAddress());
                intent.putExtra("tagline",products.get(position).getPincode());
                intent.putExtra("area",products.get(position).getDeathday());
                holder.organupdate.getContext().startActivity(intent);



            }
        });





    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    class myviewholder2 extends RecyclerView.ViewHolder
    {
        TextView organid,organname,organaddress, organmobileno,organpincode,organdeathday;
        ImageButton organdelete;

        Button organupdate;
        public myviewholder2(@NonNull View itemView) {
            super(itemView);

            organid=itemView.findViewById(R.id.organid);
            organname=itemView.findViewById(R.id.organname);
            organaddress=itemView.findViewById(R.id.organaddress);
            organmobileno=itemView.findViewById(R.id.organmobileno);
            organpincode=itemView.findViewById(R.id.organpincode);
            organdeathday=itemView.findViewById(R.id.organdeathday);
            organdelete=itemView.findViewById(R.id.organdelete);
            organupdate=itemView.findViewById(R.id.organupdate);

        }
    }




}
