package com.example.lifesaver;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import de.hdodenhof.circleimageview.CircleImageView;

public class myadapter1 extends FirebaseRecyclerAdapter<model1,myadapter1.myviewholder1> {


    public myadapter1(@NonNull FirebaseRecyclerOptions<model1> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myadapter1.myviewholder1 holder, int position, @NonNull model1 model1)
    {
        holder.address.setText(model1.getAddress());
        holder.answer.setText(model1.getAnswer());
        holder.email.setText(model1.getEmail());
        holder.mono.setText(model1.getMono());
        holder.name.setText(model1.getName());
        holder.password.setText(model1.getPassword());
        holder.pin.setText(model1.getPin());
        holder.question.setText(model1.getQuestion());
        holder.time.setText(model1.getTime());
        holder.userid.setText(model1.getUserid());
        Glide.with(holder.img_blood.getContext()).load(model1.getImg_blood()).into(holder.img_blood);


//        holder.Explore1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                FragmentManager manager;
//                manager = ((AppCompatActivity)v.getContext()).getSupportFragmentManager().beginTransaction().replace
//                                (R.id.main_menu,new descfragment(model.getCampid(),model.getCampname(),model.getStime(),model.getEtime(),model.getTagline(),model.getArea(),model.getPurl(),model.getUsername(),model.getLocation())).addToBackStack(null).commit();
//            }
//        });

        holder.Explore1_blood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppCompatActivity activity = (AppCompatActivity)v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace
                        (R.id.main_menu1,new BlooddescFragment(model1.getAddress(),model1.getAnswer(),model1.getEmail(),model1.getMono(),model1.getName(),model1.getPassword(),model1.getPin(),model1.getQuestion(),model1.getTime(),model1.getUserid(),model1.getImg_blood())).addToBackStack(null).commit();
            }
        });

    }

    @NonNull
    @Override
    public myadapter1.myviewholder1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //runtime view creation using XML file
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerowdesign_bloodbank,parent,false);
        return new myadapter1.myviewholder1(view);
    }
    public class myviewholder1 extends RecyclerView.ViewHolder
    {
        CircleImageView img_blood;
        TextView address,answer,email,mono,name,password,pin,question,time,userid;
        Button Explore1_blood;
        View rootView;

        public myviewholder1(@NonNull View itemView) {
            super(itemView);
            rootView = itemView;

//            recyclerView = (RecyclerView)itemView.findViewById(R.id.recview);
            img_blood = (CircleImageView)itemView.findViewById(R.id.img_blood);
            address = (TextView)itemView.findViewById(R.id.address);
            answer = (TextView)itemView.findViewById(R.id.answer);
            email = (TextView)itemView.findViewById(R.id.email);
            Explore1_blood = (Button)itemView.findViewById(R.id.Explore1_blood);
            mono = (TextView)itemView.findViewById(R.id.mono);
            name = (TextView)itemView.findViewById(R.id.name);
            password = (TextView)itemView.findViewById(R.id.password);
            pin = (TextView)itemView.findViewById(R.id.pin);
            question = (TextView)itemView.findViewById(R.id.question);
            time = (TextView)itemView.findViewById(R.id.time);
            userid = (TextView)itemView.findViewById(R.id.userid);


//            Explore1.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    FragmentManager manager =
//                            ((AppCompatActivity)v.getContext()).getSupportFragmentManager().beginTransaction().replace
//                            (R.id.main_menu,new descfragment(model.getCampid(),model.getCampname(),model.getStime(),model.getEtime(),model.getTagline(),model.getArea(),model.getPurl(),model.getUsername(),model.getLocation())).addToBackStack(null).commit();
//                }
//            });

        }
    }
}
