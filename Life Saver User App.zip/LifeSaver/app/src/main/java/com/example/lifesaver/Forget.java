package com.example.lifesaver;

import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.trusted.Token;

import android.media.session.MediaSession;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;


public class Forget extends AppCompatActivity {
    private EditText mobileNumberEditText, otpEditText;
    private Button generateOTPButton, verifyOTPButton;
    private TextView messageTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget);

        mobileNumberEditText = findViewById(R.id.mobileNumberEditText);
        otpEditText = findViewById(R.id.otpEditText);
        generateOTPButton = findViewById(R.id.generateOTPButton);
        verifyOTPButton = findViewById(R.id.verifyOTPButton);
        messageTextView = findViewById(R.id.messageTextView);

        generateOTPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mobileNumber = mobileNumberEditText.getText().toString();
                String otp = OTPGenerator.generateOTP();
                // You can send this OTP to the user via SMS or any other method
                messageTextView.setText("OTP generated: " + otp);
            }
        });

        verifyOTPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mobileNumber = mobileNumberEditText.getText().toString();
                String enteredOTP = otpEditText.getText().toString();
                try {
                    boolean isOTPValid = OTPVerifier.verifyOTP(mobileNumber, enteredOTP);
                    if(isOTPValid) {
                        Toast.makeText(Forget.this, "thik hai", Toast.LENGTH_SHORT).show();
                      //  messageTextView.setText("OTP verification successful!");

                    } else {
                        Toast.makeText(Forget.this, "firse karo", Toast.LENGTH_SHORT).show();
                     //   messageTextView.setText("OTP verification failed!");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

}