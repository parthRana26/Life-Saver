package com.example.lifesaver;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class BloodBank1 extends AppCompatActivity {
    BottomNavigationView bnView;
    RecyclerView recview1;
    myadapter1 adapter1;

    ImageButton voice1;

    String voiceresult;
    SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_bank1);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.my_color1));
        }


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#ff0000"));
        actionBar.setBackgroundDrawable(colorDrawable);

        bnView = findViewById(R.id.bnView);
        recview1 = (RecyclerView) findViewById(R.id.recview1);
        recview1.setLayoutManager(new LinearLayoutManager(this));

        // Initialize and assign variable
        bnView.setSelectedItemId(R.id.navigation_bloodbank);
        voice1 = findViewById(R.id.voice1);
        // Set Home selected



        FirebaseRecyclerOptions<model1> options1 =
                new FirebaseRecyclerOptions.Builder<model1>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("weblogin").child("bloodbank"), model1.class)
                        .build();
        adapter1=new myadapter1(options1);
        recview1.setAdapter(adapter1);



        bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch(item.getItemId())
                {
                    case R.id.navigation_home:
                        startActivity(new Intent(getApplicationContext(),Campaign1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_bloodbank:
                        return true;
                    case R.id.navigation_Organ:
                        startActivity(new Intent(getApplicationContext(),Organ1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_pinned:
                        startActivity(new Intent(getApplicationContext(),Pinned1.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_profile:
                        startActivity(new Intent(getApplicationContext(),Profile1.class));
                        overridePendingTransition(0,0);
                        return true;
                    default:
                        Toast.makeText(getApplicationContext(), "default section", Toast.LENGTH_SHORT).show();
                }



                return true;
            }
        });

        voice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVoiceDialog();
            }
        });

        // Perform item selected listener
//        bnView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//
//                switch(item.getItemId())
//                {
//                    case R.id.navigation_home:
//                        startActivity(new Intent(getApplicationContext(),Campaign1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_bloodbank:
//                        return true;
//                    case R.id.navigation_Organ:
//                        startActivity(new Intent(getApplicationContext(),Organ1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_pinned:
//                        startActivity(new Intent(getApplicationContext(),Pinned1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                    case R.id.navigation_profile:
//                        startActivity(new Intent(getApplicationContext(),Profile1.class));
//                        overridePendingTransition(0,0);
//                        return true;
//                }
//                return true;
//            }
//        });

    }

    private void openVoiceDialog() {

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        startActivityForResult(i,200);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 200 && resultCode == RESULT_OK)
        {
            ArrayList<String> arrayList = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            voiceresult = arrayList.get(0);
            searchView.onActionViewExpanded();
            searchView.setQuery(voiceresult,false);

        }
        else{
            Toast.makeText(this, "something was wrong", Toast.LENGTH_SHORT).show();
        }

    }
    public void onBackPressed() {
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public void onStart() {
        super.onStart();
        adapter1.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter1.stopListening();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.mainmenu,menu);
        getMenuInflater().inflate(R.menu.searchmenu,menu);

        MenuItem item = menu.findItem(R.id.search);
        searchView = (SearchView) item.getActionView();

        String myString = "Enter Pin Code";
        SpannableString spannableString = new SpannableString(myString);
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(ContextCompat.getColor(this, R.color.my_color));
        spannableString.setSpan(colorSpan, 0, myString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        searchView.setQueryHint(spannableString);

        searchView.setInputType(InputType.TYPE_CLASS_NUMBER);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                processsearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                processsearch(s);
                return false;
            }
        });


        return super.onCreateOptionsMenu(menu);


    }

    private void processsearch(String s) {

        FirebaseRecyclerOptions<model1> options1 =
                new FirebaseRecyclerOptions.Builder<model1>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("weblogin").child("bloodbank").orderByChild("pin").startAt(s).endAt(s+"\uf8ff"), model1.class)
                        .build();

        adapter1 = new myadapter1(options1);
        adapter1.startListening();
        recview1.setAdapter(adapter1);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int item_id = item.getItemId();
        if(item_id == R.id.bug_report){

            String recipientList = "neelrana79829@gmail.com";
            String[] recipients = recipientList.split(",");

            String subject = "Bug Report";

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, recipients);
            intent.putExtra(Intent.EXTRA_SUBJECT, subject);

            intent.setType("message/rfc822");
            startActivity(Intent.createChooser(intent, "Choose an email client"));

        }else if(item_id == R.id.logout){

            logout1();

        }else if(item_id == R.id.app_rating){
            Intent i = new Intent(getApplicationContext(),AppRating.class);
            startActivity(i);

        }else if(item_id == R.id.faq){
            Intent i = new Intent(getApplicationContext(),Faq.class);
            startActivity(i);

        }else if(item_id == R.id.share){
            shareapp();
        }

        return true;
    }

    private void shareapp() {

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT,"Check out this amazing app");
        i.putExtra(Intent.EXTRA_TEXT,"Check out this amazing app \n Life Saver \n https://github.com/TuathaDeLugh/Lifedistroyer");
        startActivity(Intent.createChooser(i,"Share Via"));


    }

    private void logout1() {

        SharedPreferences pref = getSharedPreferences("login",MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("flag",false);
        editor.apply();

        Intent i = new Intent(BloodBank1.this,Login.class);
        startActivity(i);
        finishAffinity();

    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter1.startListening();
        adapter1.notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        adapter1.stopListening();
        adapter1.notifyDataSetChanged();
    }
}