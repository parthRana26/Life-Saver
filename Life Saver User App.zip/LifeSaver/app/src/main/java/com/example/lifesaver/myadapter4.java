package com.example.lifesaver;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import de.hdodenhof.circleimageview.CircleImageView;

public class myadapter4 extends FirebaseRecyclerAdapter<model3, myadapter4.myviewholder4>{

        public myadapter4(@NonNull FirebaseRecyclerOptions<model3> options) {
            super(options);
        }

        @Override
        protected void onBindViewHolder(@NonNull final myadapter4.myviewholder4 holder, final int position, @NonNull final model3 model3)
        {
            holder.txt3.setText(model3.getDesc());
            Glide.with(holder.img3.getContext()).load(model3.getImage()).into(holder.img3);
            holder.buy3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }

        });

        }

        @NonNull
        @Override
        public myadapter4.myviewholder4 onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
        {
            //runtime view creation using XML file
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singleitem,parent,false);
            return new myadapter4.myviewholder4(view);
        }
        public class myviewholder4 extends RecyclerView.ViewHolder
        {
            ImageView img3;
            TextView txt3;
            Button buy3;
            View rootView;
            public myviewholder4(@NonNull View itemView) {
                super(itemView);
                rootView = itemView;
                img3 = itemView.findViewById(R.id.img3);
                txt3 = itemView.findViewById(R.id.txt3);
                buy3 = itemView.findViewById(R.id.buy3);
            }
        }
}
