package com.example.lifesaver;

import static android.content.Context.MODE_PRIVATE;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RateUsDialog extends Dialog {
    private float userRate = 0;

    public RateUsDialog(@NonNull Context context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.rate_us_dialog_layout);

        final AppCompatButton rateNowBtn = findViewById(R.id.rateNowBtn);
        final AppCompatButton leterBtn = findViewById(R.id.leterBtn);
        final RatingBar ratingBar = findViewById(R.id.ratingBar);
        final ImageView ratingImage = findViewById(R.id.ratingImage);
        final EditText feedback = findViewById(R.id.feedback);

        rateNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Getting the rating and displaying it on the toast  
                String rating = String.valueOf(ratingBar.getRating());
                String getFeed = String.valueOf(feedback.getText());

                SharedPreferences sharedPreferences = getContext().getSharedPreferences("myKey", MODE_PRIVATE);
                String wow1 = sharedPreferences.getString("value","");


                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
                        ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");


                databaseReference.child("App Rating").child("rating").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        {

                            databaseReference.child("App Rating").child("rating").child(wow1).child("rating").setValue(rating);
                            databaseReference.child("App Rating").child("rating").child(wow1).child("Feedback").setValue(getFeed);

                            Snackbar.make(view,"Thank You "+" "+wow1,3000).show();

                            feedback.setText("");
                            ratingBar.setRating(3.0f);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        leterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //hide rating dialog
                dismiss();
            }
        });

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean b) {

                if (rating <= 1){
                    ratingImage.setImageResource(R.drawable.one_star);
                }
                else if (rating <= 2) {
                    ratingImage.setImageResource(R.drawable.two_star);
                }
                else if (rating <= 3) {
                    ratingImage.setImageResource(R.drawable.three_star);
                }
                else if (rating <= 4) {
                    ratingImage.setImageResource(R.drawable.four_star);
                }
                else if (rating <= 5) {
                    ratingImage.setImageResource(R.drawable.five_star);
                }

                //animate emoji image
                animateImage(ratingImage);

                //selected rating by user
                userRate = rating;
            }
        });
    }

    private void animateImage(ImageView ratingImage){
        ScaleAnimation scaleAnimation = new ScaleAnimation(0,1f,0,1f, Animation.RELATIVE_TO_SELF,
                0.5f,Animation.RELATIVE_TO_SELF,0.5f);

        scaleAnimation.setFillAfter(true);
        scaleAnimation.setDuration(200);
        ratingImage.startAnimation(scaleAnimation);
    }

}
