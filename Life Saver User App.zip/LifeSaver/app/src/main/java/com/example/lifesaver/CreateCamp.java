package com.example.lifesaver;

import static com.google.android.material.color.utilities.MaterialDynamicColors.error;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.InputStream;

public class CreateCamp extends AppCompatActivity {

    TextInputEditText idob,nameob,addressob,monoob,taglineob,pinob,useridob;
    ImageButton lctbtnob;
    Button b1,b2,browse,submitob;
    TextView t1,t2,locationop;
    ImageView img;
    DatePicker datePickerob;
    Uri filepath;
    Bitmap bitmap;
    String day,month,year,date,time,map,id,name,address,mono,tag,pin,userid,a,b,c,uristr,wow;

    StorageReference storageReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_camp);

        lctbtnob= (ImageButton) findViewById(R.id.lctbtn);
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button)findViewById(R.id.b2);
        locationop = (TextView) findViewById(R.id.locationop);
        img = (ImageView) findViewById(R.id.img);
        browse =(Button) findViewById(R.id.browse);
        submitob = (Button) findViewById(R.id.submit);
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        t1 = (TextView) findViewById(R.id.t1);
        t2 = (TextView) findViewById(R.id.t2);
        useridob = (TextInputEditText) findViewById(R.id.useridob);

        lctbtnob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(CreateCamp.this,MapsActivity.class);
                startActivity(i);
                finish();
            }
        });


        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        wow = sharedPreferences.getString("value","");
        useridob.setText(String.valueOf(wow));

//        Intent intent = getIntent();
//        a = intent.getStringExtra("a");
//        b = intent.getStringExtra("b");
//        c = String.valueOf(a)+","+String.valueOf(b);
//        locationop.setText(c);
//
        double latitude = getIntent().getDoubleExtra("a", 0);
        double longitude = getIntent().getDoubleExtra("b", 0);

        locationop.setText(latitude +","+ longitude);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog1();
            }
        });
        browse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dexter.withContext(CreateCamp.this)
                        .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        .withListener(new PermissionListener() {
                            @Override
                            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                                Intent intent=new Intent(Intent.ACTION_PICK);
                                intent.setType("image/*");
                                startActivityForResult(Intent.createChooser(intent,"Select Image File"),1);
                            }

                            @Override
                            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

                            }

                            @Override
                            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                                permissionToken.continuePermissionRequest();
                            }
                        }).check();

                submitob.setVisibility(View.VISIBLE);

            }
        });

        submitob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             //   validation();
                uploadtofirebase();
                Snackbar.make(v,"Campaign information is sent",3000).show();
            }
        });



    }

    private void validation() {

        if(id.isEmpty()){
            idob.setError("enter value");
        }else{
            idob.setError(null);
        }

        if(name.isEmpty()){
            nameob.setError("enter name");
        }else{
            nameob.setError(null);
        }

        if(address.isEmpty()){
            addressob.setError("enter address");
        }else{
            addressob.setError(null);
        }

        if(mono.isEmpty()){
            monoob.setError("enter mobileno");
        }else{
            monoob.setError(null);
        }

        if(tag.isEmpty()){
            taglineob.setError("enter tag line");
        }else{
            taglineob.setError(null);
        }


        if(pin.isEmpty()){
            pinob.setError("enter pin code");
        }else{
            pinob.setError(null);
        }
    }

    private void openDialog1() {

        TimePickerDialog dialog2 = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                t2.setText(hourOfDay +":"+ minute);
            }
        }, 15, 00, true);
        dialog2.show();

    }

    private void openDialog() {
        TimePickerDialog dialog1 = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                t1.setText(hourOfDay +":"+ minute);
            }
        }, 15, 00, true);
        dialog1.show();
    }

    private void uploadtofirebase() {

        ProgressDialog dialog = new ProgressDialog(this);
        dialog.setTitle("Info Uploader");
        dialog.show();

        idob = (TextInputEditText) findViewById(R.id.id);
        nameob = (TextInputEditText) findViewById(R.id.name);
        addressob = (TextInputEditText) findViewById(R.id.address);
        monoob = (TextInputEditText) findViewById(R.id.mono);
        taglineob = (TextInputEditText) findViewById(R.id.tag);
        pinob = (TextInputEditText) findViewById(R.id.pinob);

        datePickerob = (DatePicker) findViewById(R.id.datepicker);

        day = String.valueOf(datePickerob.getDayOfMonth());
        month = String.valueOf(datePickerob.getMonth() + 1);
        year = String.valueOf(datePickerob.getYear());
        date = String.valueOf(String.valueOf(day) + "/" + String.valueOf(month) + "/" + String.valueOf(year));
        time = String.valueOf(String.valueOf(t1.getText().toString()) + " To " + String.valueOf(t2.getText().toString()));
        map = String.valueOf(locationop.getText());

        id = String.valueOf(idob.getText());
        name = String.valueOf(nameob.getText());
        address = String.valueOf(addressob.getText());
        mono = String.valueOf(monoob.getText());
        tag = String.valueOf(taglineob.getText());
        pin = String.valueOf(pinob.getText());
        userid = String.valueOf(useridob.getText());


        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
                ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");

        storageReference= FirebaseStorage.getInstance().getReference();

        databaseReference.child("campaign").child("notapprove").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChild(id)) {
                    Toast.makeText(getApplicationContext(), "Campaign Request is already registered",
                            Toast.LENGTH_SHORT).show();
                } else {

                    databaseReference.child("campaign").child("notapprove").child(id).child("id").setValue(id);
                    databaseReference.child("campaign").child("notapprove").child(id).child("name").setValue(name);
                    databaseReference.child("campaign").child("notapprove").child(id).child("address").setValue(address);
                    databaseReference.child("campaign").child("notapprove").child(id).child("mono").setValue(mono);
                    databaseReference.child("campaign").child("notapprove").child(id).child("date").setValue(date);
                    databaseReference.child("campaign").child("notapprove").child(id).child("map").setValue(map);
                    databaseReference.child("campaign").child("notapprove").child(id).child("pin").setValue(pin);

                    databaseReference.child("campaign").child("notapprove").child(id).child("tag").setValue(tag);
                    databaseReference.child("campaign").child("notapprove").child(id).child("userid").setValue(userid);
                    databaseReference.child("campaign").child("notapprove").child(id).child("time").setValue(time);

                    StorageReference reference = storageReference.child("imageuploads/"+System.currentTimeMillis()+".jpeg");
                    reference.putFile(filepath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
                        {
                            reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                  //  uristr = String.valueOf(uri);
                                    uristr = uri.toString();
                                    databaseReference.child("campaign").child("notapprove").child(id).child("image").setValue(uristr);

                                    idob.setText("");
                                    nameob.setText("");
                                    addressob.setText("");
                                    pinob.setText("");
                                    monoob.setText("");
                                    useridob.setText("");
                                    taglineob.setText("");
                                    img.setImageBitmap(null);
                                    filepath =null;
                                    dialog.dismiss();
                                    Toast.makeText(getApplicationContext(),
                                            "Campaign Request Registered Successfully",
                                            Toast.LENGTH_SHORT);
                                }
                            });
                        }
                    }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                            float percent=(100*snapshot.getBytesTransferred())/snapshot.getTotalByteCount();
                            dialog.setMessage("Uploaded: "+(int)percent+" %");
                        }
                    });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
        {
            if(requestCode==1  && resultCode==RESULT_OK)
            {
                filepath=data.getData();
                try{
                    InputStream inputStream=getContentResolver().openInputStream(filepath);
                    bitmap= BitmapFactory.decodeStream(inputStream);
                    img.setImageBitmap(bitmap);
                }catch (Exception ex)
                {

                }
            }

            super.onActivityResult(requestCode, resultCode, data);
        }
}