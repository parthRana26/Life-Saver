package com.example.lifesaver;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BloodData#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BloodData extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    String abnve,abpnv,anve,apve,bnve,bpve,onve,opve;

    TextView o1,o2,o3,o4,o5,o6,o7,o8,o9,o10,o11,o12,o13,o14,o15,o16,o17,o18;

    public BloodData() {
        // Required empty public constructor
    }

//    public BloodData(String abnve,String abpnv,String anve,String apve,String bnve,String bpve,String onve,String opve){
//
//        this.abnve = abnve;
//        this.abpnv = abpnv;
//        this.anve = anve;
//        this.apve = apve;
//        this.bnve = bnve;
//        this.bpve = bpve;
//        this.onve = onve;
//        this.opve = opve;
//
//    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BloodData.
     */
    // TODO: Rename and change types and number of parameters
    public static BloodData newInstance(String param1, String param2) {
        BloodData fragment = new BloodData();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_blood_data, container, false);

        TextView txt = view.findViewById(R.id.txt);
         o1 = view.findViewById(R.id.o1);
         o2 = view.findViewById(R.id.o2);
         o3 = view.findViewById(R.id.o3);
         o4 = view.findViewById(R.id.o4);
         o5 = view.findViewById(R.id.o5);
         o6 = view.findViewById(R.id.o6);
         o7 = view.findViewById(R.id.o7);
         o8 = view.findViewById(R.id.o8);
         o9 = view.findViewById(R.id.o9);
         o18 = view.findViewById(R.id.o18);
         o10 = view.findViewById(R.id.o10);
         o11 = view.findViewById(R.id.o11);
         o12 = view.findViewById(R.id.o12);
         o13 = view.findViewById(R.id.o13);
         o14 = view.findViewById(R.id.o14);
         o15 = view.findViewById(R.id.o15);
         o16 = view.findViewById(R.id.o16);
         o17 = view.findViewById(R.id.o17);

        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("Buserid", MODE_PRIVATE);
        String blooduserid = sharedPreferences.getString("userid","");


        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl
                ("https://finalproject1-c0216-default-rtdb.asia-southeast1.firebasedatabase.app");

        databaseReference.child("blooddata").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.hasChild(blooduserid)){


                    abnve = snapshot.child(blooduserid).child("abnve").getValue(String.class);
                    abpnv = snapshot.child(blooduserid).child("abpve").getValue(String.class);
                    anve = snapshot.child(blooduserid).child("anve").getValue(String.class);
                    apve = snapshot.child(blooduserid).child("apve").getValue(String.class);
                    bnve = snapshot.child(blooduserid).child("bnve").getValue(String.class);
                    bpve = snapshot.child(blooduserid).child("bpve").getValue(String.class);
                    onve = snapshot.child(blooduserid).child("onve").getValue(String.class);
                    opve = snapshot.child(blooduserid).child("opve").getValue(String.class);

                    o10.setText(abnve);
                    o11.setText(abpnv);
                    o12.setText(anve);
                    o13.setText(apve);
                    o14.setText(bnve);
                    o15.setText(bpve);
                    o16.setText(onve);
                    o17.setText(opve);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });






        return view;
    }


}