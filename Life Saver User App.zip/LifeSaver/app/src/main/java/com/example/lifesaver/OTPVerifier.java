package com.example.lifesaver;

import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.IOException;

public class OTPVerifier {

    private static final String API_ENDPOINT = "https://your-api-endpoint.com/verify-otp";

    public static boolean verifyOTP(String mobileNumber, String otp) throws IOException {
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = new FormBody.Builder()
                .add("mobile_number", mobileNumber)
                .add("otp", otp)
                .build();
        Request request = new Request.Builder()
                .url(API_ENDPOINT)
                .post(requestBody)
                .build();
        Response response = client.newCall(request).execute();
        String responseBody = response.body().string();
        return responseBody.equals("success");
    }

}