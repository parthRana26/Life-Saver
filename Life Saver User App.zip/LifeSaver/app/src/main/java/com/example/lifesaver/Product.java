package com.example.lifesaver;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Product {

    @PrimaryKey(autoGenerate = true)
    public int oid;

    @ColumnInfo(name = "oname")
    public String oname;

    @ColumnInfo(name = "mobileno")
    public String mobileno;

    @ColumnInfo(name = "address")
    public String address;

    @ColumnInfo(name = "pincode")
    public String pincode;

    @ColumnInfo(name = "deathday")
    public String deathday;

    public Product(int oid, String oname, String mobileno, String address, String pincode, String deathday) {
        this.oid = oid;
        this.oname = oname;
        this.mobileno = mobileno;
        this.address = address;
        this.pincode = pincode;
        this.deathday = deathday;
    }


    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }

    public String getOname() {
        return oname;
    }

    public void setOname(String oname) {
        this.oname = oname;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getDeathday() {
        return deathday;
    }

    public void setDeathday(String deathday) {
        this.deathday = deathday;
    }
}
