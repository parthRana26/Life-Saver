package com.example.lifesaver;

public class model3 {

    String desc,image;

    public model3() {
    }

    public model3(String desc, String image) {
        this.desc = desc;
        this.image = image;
    }


    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
