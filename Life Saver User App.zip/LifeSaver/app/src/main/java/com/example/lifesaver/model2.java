package com.example.lifesaver;

public class model2 {

    String address,deathday,mobileno,organuserid,organname,pincode;

    public model2() {
    }

    public model2(String address, String deathday, String mobileno, String organuserid, String organname, String pincode) {
        this.address = address;
        this.deathday = deathday;
        this.mobileno = mobileno;
        this.organuserid = organuserid;
        this.organname = organname;
        this.pincode = pincode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDeathday() {
        return deathday;
    }

    public void setDeathday(String deathday) {
        this.deathday = deathday;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getOrganuserid() {
        return organuserid;
    }

    public void setOrganuserid(String organuserid) {
        this.organuserid = organuserid;
    }

    public String getOrganname() {
        return organname;
    }

    public void setOrganname(String organname) {
        this.organname = organname;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}
