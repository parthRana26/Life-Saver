package com.example.lifesaver;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class myadapter3 extends FirebaseRecyclerAdapter<model2,myadapter3.myviewholder3> {



    public myadapter3(@NonNull FirebaseRecyclerOptions<model2> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final myadapter3.myviewholder3 holder, final int position, @NonNull final model2 model2)
    {
        holder.ooname.setText(model2.getOrganuserid());
        holder.ooid.setText(model2.getOrganname());
        holder.ootag.setText(model2.getDeathday());
        holder.oopin.setText(model2.getAddress());
        holder.ootime.setText(model2.getPincode());
        holder.ooExplore1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = model2.getMobileno();
                Intent intent =new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+number));
                v.getContext().startActivity(intent);
            }
        });


    }

    @NonNull
    @Override
    public myadapter3.myviewholder3 onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //runtime view creation using XML file
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerowdesign1,parent,false);
        return new myadapter3.myviewholder3(view);
    }


    public class myviewholder3 extends RecyclerView.ViewHolder
    {
        ImageView ooimage;
        TextView ooname,ooid,ootag,oopin,ootime;
        Button ooExplore1;
        View rootView;

        public myviewholder3(@NonNull View itemView) {
            super(itemView);
            rootView = itemView;

//            recyclerView = (RecyclerView)itemView.findViewById(R.id.recview);
            ooimage = (ImageView)itemView.findViewById(R.id.ooimage);
            ooname = (TextView)itemView.findViewById(R.id.ooname);
            ooid = (TextView)itemView.findViewById(R.id.ooid);
            ootag = (TextView)itemView.findViewById(R.id.ootag);
            oopin = (TextView)itemView.findViewById(R.id.oopin);
            ootime = (TextView)itemView.findViewById(R.id.ootime);
            ooExplore1 = (Button)itemView.findViewById(R.id.ooExplore1);

        }
    }


}
